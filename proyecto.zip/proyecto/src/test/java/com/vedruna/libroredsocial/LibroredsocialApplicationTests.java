package com.vedruna.libroredsocial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibroredsocialApplicationTests {

	@Test
	void contextLoads() {
	}

}
