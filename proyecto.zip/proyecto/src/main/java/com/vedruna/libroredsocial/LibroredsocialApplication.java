package com.vedruna.libroredsocial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibroredsocialApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibroredsocialApplication.class, args);
	}

}
